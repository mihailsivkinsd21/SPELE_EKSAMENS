// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MyGameModer.generated.h"

/**
 * 
 */
UCLASS()
class POEHALI_API AMyGameModer : public AGameModeBase
{
	GENERATED_BODY()

	AMyGameModer();

	public:
	UPROPERTY (EditAnywhere)
	int scores=0;
	void AddScore();
	
	
};
