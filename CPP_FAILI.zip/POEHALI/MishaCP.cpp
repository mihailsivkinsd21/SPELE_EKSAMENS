// Fill out your copyright notice in the Description page of Project Settings.

#include "MishaCP.h"
#include "Components/InputComponent.h"
#include "EngineGlobals.h"
#include "Engine/Engine.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
AMishaCP::AMishaCP()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bTickEvenWhenPaused = true;

}

void AMishaCP::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}
// Called when the game starts or when spawned
void AMishaCP::BeginPlay()
{
	Super::BeginPlay();
	InputComponent->BindAxis("MoveForward", this, &AMishaCP::MoveForward);
	InputComponent->BindAxis("MoveRight", this, &AMishaCP::MoveRight);
	InputComponent->BindAxis("LookUp", this, &AMishaCP::LookUp);
	InputComponent->BindAxis("Turn", this, &AMishaCP::Turn);
	InputComponent->BindAction("Pause", IE_Released, this, &AMishaCP::Pause).bExecuteWhenPaused = true;
	

}

// Called every frame
void AMishaCP::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	

}



void AMishaCP::MoveForward(float move)
{
	if (Controller && move) {
		AddMovementInput(GetActorForwardVector(), move);
	}

}

void AMishaCP::MoveRight(float move)
{

	if (Controller && move) {
		AddMovementInput(GetActorRightVector(), move);
	}


}

void AMishaCP::LookUp(float move)
{
	if (Controller && move) {
		AddControllerPitchInput(move);
	}

}

void AMishaCP::Turn(float move) 
{
	if (Controller && move) {
		AddControllerYawInput(move);
	}

}

void AMishaCP::Pause() {
	APlayerController* const MyPlayer = Cast<APlayerController>(GEngine->GetFirstLocalPlayerController(GetWorld()));
	if (MyPlayer != NULL)
	{
		if (ispaused) {
			MyPlayer->SetPause(0);
			ispaused = false;
		}
		else {
			MyPlayer->SetPause(1);
			ispaused = true;
		}

	}
}



