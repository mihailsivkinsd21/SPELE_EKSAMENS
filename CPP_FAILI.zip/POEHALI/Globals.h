// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Globals.generated.h"

UCLASS()
class POEHALI_API AGlobals : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AGlobals();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	int score = 0;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	void setScore();
	void setBonusScore();
	FTimerHandle timing;
	void Timing();
	void EndGame();
	float starttime;
	//TSubclassOf<class UScoreAndTime> MyClass;
	UPROPERTY(BlueprintReadWrite)
	float time;
	
};
