// Fill out your copyright notice in the Description page of Project Settings.

#include "MainMenuClass.h"
#include <windows.h>
#include <Rekords.h>
#include <fstream>


void UMainMenuClass::openScores() {
	ShellExecute(NULL, L"open", L"scoresoutput.txt", NULL, NULL, SW_SHOWDEFAULT);
}


void UMainMenuClass::updateScores() { //funkcija pogai UPDATE SCOREBOARD (kuru izmanto ja fails ar scoreboardu bija salauzts
	Rekords rek;

	std::ifstream readscores;
	readscores.open("scores.txt");

	std::ofstream scoresoutput;
	scoresoutput.open("scoresoutput.txt", std::ofstream::trunc);

	int elem_skaits = 0;
	while (readscores.read((char*)&rek, sizeof(Rekords))) {
		elem_skaits++;
	}

	readscores.close();
	readscores.open("scores.txt");
	Rekords * rekordu_masivs = new Rekords[elem_skaits];
	int skaititajs = 0;

	while (readscores.read((char*)&rek, sizeof(Rekords))) {
		strcpy(rekordu_masivs[skaititajs].name, rek.name);
		rekordu_masivs[skaititajs].score = rek.score;
		rekordu_masivs[skaititajs].kpd = rek.kpd;
		skaititajs = skaititajs + 1;
	}
	readscores.close();

	int temp;
	double temp_kpd;
	char temp_name[20];
	for (int i = 0; i <= elem_skaits - 1; i++) {
		for (int j = 0; j <= elem_skaits - 1; j++) {
			if (rekordu_masivs[j].score < rekordu_masivs[j + 1].score) {
				temp = rekordu_masivs[j].score;
				temp_kpd = rekordu_masivs[j].kpd;
				strcpy(temp_name, rekordu_masivs[j].name);

				rekordu_masivs[j].score = rekordu_masivs[j + 1].score;
				rekordu_masivs[j].kpd = rekordu_masivs[j + 1].kpd;
				strcpy(rekordu_masivs[j].name, rekordu_masivs[j + 1].name);
				rekordu_masivs[j + 1].score = temp;
				rekordu_masivs[j + 1].kpd = temp_kpd;
				strcpy(rekordu_masivs[j + 1].name, temp_name);
			}
		}
	}

	scoresoutput << "-----------------------" << std::endl;
	scoresoutput << "TOP 10: " << std::endl;
	scoresoutput << std::endl;
	for (int i = 0; i <= elem_skaits - 1; i++) {
		scoresoutput << i + 1 << ". " << rekordu_masivs[i].name << std::endl;
		scoresoutput << "   Score: " << rekordu_masivs[i].score << std::endl;
		scoresoutput << "   Score/Time: " << rekordu_masivs[i].kpd << std::endl;
		scoresoutput << std::endl;
		if (i == 9) {
			scoresoutput << "-----------------------" << std::endl;
			scoresoutput << "OTHER: " << std::endl;
			scoresoutput << std::endl;
		}
	}

	scoresoutput.close();
}


