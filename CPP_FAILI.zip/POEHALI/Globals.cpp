// Fill out your copyright notice in the Description page of Project Settings.

#include "Globals.h"
#include "Engine/Engine.h"
#include "Components/InputComponent.h"
#include "EngineGlobals.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include "WidgetBlueprintLibrary.h"
#include "ConstructorHelpers.h"
#include "Rekords.h"

// Sets default values
AGlobals::AGlobals()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AGlobals::BeginPlay()
{
	Super::BeginPlay();
	GetWorld()->GetTimerManager().SetTimer(timing, this, &AGlobals::Timing, 5.0f, true);
	time = 30;
	starttime = time;
}

// Called every frame
void AGlobals::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AGlobals::setScore() {

	score = score + 1;
	FString debug = "1 score point added! Points : " + FString::SanitizeFloat(score*1.0);
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, *debug);

	

}

void AGlobals::setBonusScore() {

	score = score + 2;
	FString debug = "2 score point added! Points : " + FString::SanitizeFloat(score*1.0);
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, *debug);

}

void AGlobals::Timing() {

	time = time - 5;

	if (time <= 0) {
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("TIME OUT!"));
		EndGame();
	}

}

void AGlobals::EndGame() {

	Rekords rek;
	std::ifstream name;
	name.open("name.txt");

	name >> rek.name;
	rek.score = score;
	rek.kpd = score / 30.0;
	name.close();

	std::ofstream scores;
	scores.open("scores.txt",std::ofstream::app);
	scores.write((char*)&rek, sizeof(Rekords));
	scores.close();

	std::ifstream readscores;
	readscores.open("scores.txt");

	std::ofstream scoresoutput;
	scoresoutput.open("scoresoutput.txt", std::ofstream::trunc);
	
	int elem_skaits = 0;
	while (readscores.read((char*)&rek, sizeof(Rekords))) {
		elem_skaits++;
	}

	readscores.close();
	readscores.open("scores.txt");
	Rekords * rekordu_masivs = new Rekords[elem_skaits];
	int skaititajs = 0;

	while (readscores.read((char*)&rek, sizeof(Rekords))) {
		strcpy(rekordu_masivs[skaititajs].name, rek.name);
		rekordu_masivs[skaititajs].score = rek.score;
		rekordu_masivs[skaititajs].kpd = rek.kpd;
		skaititajs = skaititajs + 1;
	}
	readscores.close();

	int temp;
	double temp_kpd;
	char temp_name[20];
	for (int i = 0; i <= elem_skaits-1; i++) {
		for (int j = 0; j <= elem_skaits-1; j++) {
			if (rekordu_masivs[j].score < rekordu_masivs[j + 1].score) {
				temp = rekordu_masivs[j].score;
				temp_kpd = rekordu_masivs[j].kpd;
				strcpy(temp_name, rekordu_masivs[j].name);
				
				rekordu_masivs[j].score = rekordu_masivs[j + 1].score;
				rekordu_masivs[j].kpd = rekordu_masivs[j + 1].kpd;
				strcpy(rekordu_masivs[j].name, rekordu_masivs[j + 1].name);
				rekordu_masivs[j + 1].score = temp;
				rekordu_masivs[j + 1].kpd = temp_kpd;
				strcpy(rekordu_masivs[j + 1].name, temp_name);
			}
		}
	}

	scoresoutput << "-----------------------" << std::endl;
	scoresoutput << "TOP 10: " << std::endl;
	scoresoutput << std::endl;
	for (int i = 0; i <= elem_skaits - 1; i++) {
		scoresoutput << i+1 << ". " << rekordu_masivs[i].name << std::endl;
		scoresoutput << "   Score: " << rekordu_masivs[i].score << std::endl;
		scoresoutput << "   Score/Time: " << rekordu_masivs[i].kpd << std::endl;
		scoresoutput << std::endl;
		if (i == 9) {
			scoresoutput << "-----------------------" << std::endl;
			scoresoutput << "OTHER: " << std::endl;
			scoresoutput << std::endl;
		}
	}

	scoresoutput.close();



	UGameplayStatics::OpenLevel(GetWorld(), TEXT("/Game/MENU"), TRAVEL_Absolute);
	FString debug = "Your score/time is " + FString::SanitizeFloat(score/starttime);
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, *debug);
	Destroy();

}

