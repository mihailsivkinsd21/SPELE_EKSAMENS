// Fill out your copyright notice in the Description page of Project Settings.

#include "Target.h"
#include "Components/StaticMeshComponent.h" 
#include "GameFramework/Actor.h"
#include "Kismet/GameplayStatics.h"
#include "Components/ActorComponent.h"
#include "EngineGlobals.h"
#include "Engine/Engine.h"
#include "MishaCP.h"
#include <time.h>  
#include "MyGameModer.h"
#include "ConstructorHelpers.h"
#include "Globals.h"
#include "EngineUtils.h"

//#include "MyGameModer.h"

// Sets default values
ATarget::ATarget(const FObjectInitializer& objectInitializer)
	:Super(objectInitializer)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	target_collision = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("collision"));
	Right = true;
	StartLocation = GetActorLocation().X;
	target_collision->OnComponentBeginOverlap.AddDynamic(this, &ATarget::Onhit);




}

// Called when the game starts or when spawned
void ATarget::BeginPlay()
{
	
	Super::BeginPlay();
	StartLocation = GetActorLocation().X;
	target_collision->OnComponentBeginOverlap.AddDynamic(this, &ATarget::Onhit);


}

// Called every frame - parvietojums
void ATarget::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	FVector NewLocation = GetActorLocation();
	if (Right) {
		if (NewLocation.X < StartLocation + offsetx) {
			NewLocation.X += speed;
		}
		else Right = false;
	}
	else {
		if (NewLocation.X > StartLocation -offsetx) {
			NewLocation.X += -speed;
		}
		else Right = true;
	}
	SetActorLocation(NewLocation);

}
void ATarget::Respawn() {

	srand(time(NULL));
	float z = rand() %200;
	float y = rand() % 2000;
	FVector NewLocation;
	NewLocation.Z =  z;
	NewLocation.Y = y;
	NewLocation.X = 0;
	speed = rand() % 15 + 10;
	SetActorLocation(NewLocation);
	StartLocation = GetActorLocation().X;
	mat = rand() % 4;
	switch (mat) {
		case 0: target_collision->SetMaterial(0, Material1); break;
		case 1: target_collision->SetMaterial(0, Material2); break;
		case 2: target_collision->SetMaterial(0, Material3); break;
		case 3: target_collision->SetMaterial(0, Bonus); break;
	}
	Right = true;
	health = 30;
}

void ATarget::Onhit(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,UPrimitiveComponent* OtherComp,int32 OtherBodyIndex,bool bFromSweep,const FHitResult &SweepResult) {
	health = health - damage;

	if (health <= 0) {
		TArray<AActor*> FoundActors; 
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), AGlobals::StaticClass(), FoundActors); // izveido massivu ar visiem elementiem no klassa globals (ir tikai viens, izmannto lai to atrast)
		for (AActor* TActor : FoundActors) //katram globals maina mainigos
		{
			AGlobals* MyActor = Cast<AGlobals>(TActor);

			if (MyActor != nullptr) {
				if (mat == 3) {
					MyActor->setBonusScore();
				} else {
					MyActor->setScore();
				}
			}		
		}
		Respawn();
	
	}
}



