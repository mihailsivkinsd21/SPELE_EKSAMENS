// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class POEHALI_API Rekords
{
public:
	
	int score;
	double kpd;
	char name[20];

	Rekords();
	~Rekords();
};
//klasi rekords izmanto lai ierakstit faila records.txt score, score/time un vardu uzreiz ka vienu objektu