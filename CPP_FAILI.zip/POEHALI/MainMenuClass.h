// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "MainMenuClass.generated.h"

/**
 * 
 */
UCLASS() // augsklasse izvelnes blueprintam
class POEHALI_API UMainMenuClass : public UUserWidget
{
	GENERATED_BODY()
	
	public:
		//UFUNCTION - lai padot funkciju child blueprintiem
		UFUNCTION(BlueprintCallable, Category = "FileOpeners")
		void openScores(); //izmanto pogai SCOREBOARD
		UFUNCTION(BlueprintCallable, Category = "FileUpdaters")
		void updateScores(); //izmanto pogai UPDATE SCOREBOARD
	
	
};
