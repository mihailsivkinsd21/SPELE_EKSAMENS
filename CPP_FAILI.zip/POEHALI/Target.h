// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MyGameModer.h"
#include "Target.generated.h"


UCLASS()
class POEHALI_API ATarget : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ATarget(const FObjectInitializer& objectInitializer);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	//uproperty izmantoju, lai iedot

	UPROPERTY(EditAnywhere)
	UStaticMeshComponent * target_collision; //komponents, ar kuru tiek parbaudita sadursme

	UPROPERTY (EditAnywhere)
	int offsetx; //par cik bumbai ir japarvietojas uz pusi
	 
	bool Right; //vai kustas pa labi - izmanto parvietojumam

	UPROPERTY(EditAnywhere)
	float speed; //parv. atrums

	UPROPERTY(EditAnywhere)
	float StartLocation; //x koordinates sakuma

	UFUNCTION()
	void Onhit(UPrimitiveComponent* OverlappedComponent,AActor* OtherActor,UPrimitiveComponent* OtherComp,int32 OtherBodyIndex,bool bFromSweep,const FHitResult &SweepResult); //trigerojas, kad notiek sadursme

	UPROPERTY(EditAnywhere)
	float health=30; // sakuma HP

	int damage = 10; // cik HP atnemt

	void Respawn(); //izpildas kad sfera "nomir"

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* Material1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* Material2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* Material3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* Bonus; // materials, ar kuru apzime bonusa sferu

	int mat = 0; // izmanto ar if 

	


};
