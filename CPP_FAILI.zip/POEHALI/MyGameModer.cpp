// Fill out your copyright notice in the Description page of Project Settings.

#include "MyGameModer.h"
#include "EngineGlobals.h"
#include "Engine/Engine.h"
#include "MishaCP.h"

void AMyGameModer::AddScore() {
	
	scores++;
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("SCOREPOINT ADDED!"));



}

AMyGameModer::AMyGameModer() {

}

